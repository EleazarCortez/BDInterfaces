﻿Public Class Form3
    Private Sub EditarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditarToolStripMenuItem.Click

    End Sub

    Private Sub GestinarEmpleadoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GestinarEmpleadoToolStripMenuItem.Click

    End Sub
End Class